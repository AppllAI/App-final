// Fenêtre de l'extension : connexion par clé, offre reconnue, « Remplir cette page ».
// Les données viennent du compte Applai de la personne (clé de ses Réglages) ; rien n'est envoyé au site visité :
// le script se contente d'écrire dans les champs du formulaire ouvert. C'est elle qui relit et clique « Envoyer ».
"use strict";
const api = globalThis.browser ?? globalThis.chrome;
const API = "https://api.89-116-25-119.sslip.io";
// Règle du projet : jamais d'automatisation sur ces sites (leurs conditions d'utilisation l'interdisent)
const INTERDITS = /(^|\.)(linkedin\.com|jobat\.be|stepstone\.[a-z.]+)$/i;
const LIBELLES = { prenom: "Prénom", nom: "Nom", email: "Email", telephone: "Téléphone", adresse: "Adresse",
  code_postal: "Code postal", ville: "Ville", pays: "Pays", linkedin: "LinkedIn" };
const $ = (s) => document.querySelector(s);
const el = (tag, cls, texte) => { const e = document.createElement(tag); if (cls) e.className = cls; if (texte !== undefined) e.textContent = texte; return e; };
let cle = null, profil = null, onglet = null;

async function appel(chemin, options = {}) {
  const r = await fetch(API + chemin, { method: options.methode || "GET", headers: { "X-Cle-Extension": cle }, credentials: "omit" });
  if (r.status === 401) { await api.storage.local.remove("cle"); cle = null; throw Object.assign(new Error("Clé refusée : crée une nouvelle clé dans tes Réglages Applai."), { connexion: true }); }
  if (!r.ok) { let m = "Erreur " + r.status; try { m = (await r.json()).detail || m; } catch (e) { /* pas du JSON */ } throw new Error(m); }
  return options.brut ? r.arrayBuffer() : r.json();
}

function montrer(id) { for (const x of ["connexion", "principal"]) $("#" + x).hidden = x !== id; }

// ---------- Connexion ----------
$("#form-cle").onsubmit = async (ev) => {
  ev.preventDefault();
  const v = $("#cle").value.trim();
  $("#erreur-cle").textContent = "";
  if (!/^aplx_[\w-]{20,}$/.test(v)) { $("#erreur-cle").textContent = "Ce n'est pas une clé Applai (elle commence par aplx_)."; return; }
  // Firefox et Safari demandent l'accord pour parler au serveur Applai (Chrome l'a déjà à l'installation)
  try { if (api.permissions && !(await api.permissions.request({ origins: [API + "/*"] }))) { $("#erreur-cle").textContent = "Autorise l'accès au serveur Applai pour continuer."; return; } }
  catch (e) { /* déjà autorisé */ }
  cle = v;
  try { await charger(); await api.storage.local.set({ cle: v }); }
  catch (e) { cle = null; $("#erreur-cle").textContent = e.message; montrer("connexion"); }
};

// ---------- La page ouverte ----------
async function charger() {
  profil = await appel("/api/extension/profil");
  montrer("principal");
  const f = profil.fiche;
  const qui = $("#qui"); qui.textContent = "";
  qui.append(el("b", "", `${f.prenom} ${f.nom}`.trim() || "Profil Applai"), el("span", "", [f.email, f.telephone].filter(Boolean).join(" · ")));
  const essai = new URLSearchParams(location.search).get("onglet");      // tests automatiques seulement
  [onglet] = essai ? [await api.tabs.get(Number(essai))] : await api.tabs.query({ active: true, currentWindow: true });
  let hote = "";
  try { hote = new URL(onglet.url).hostname.replace(/^www\./, ""); } catch (e) { /* page interne */ }
  const interdit = $("#interdit");
  interdit.hidden = true; $("#zone-remplir").hidden = false;
  if (!/^https?:/.test(onglet.url || "")) {
    interdit.hidden = false; interdit.textContent = "Ouvre la page du formulaire de candidature, puis clique à nouveau sur Applai.";
    $("#zone-remplir").hidden = true;
  } else if (INTERDITS.test(hote)) {
    interdit.hidden = false; interdit.textContent = "Applai ne remplit rien sur ce site : ses règles interdisent toute automatisation. Utilise « Copier un champ » ci-dessous.";
    $("#zone-remplir").hidden = true;
  }
  // L'offre de cette page (même site), sinon le dernier choix fait sur ce site
  const choix = $("#offre"); choix.textContent = "";
  choix.append(new Option("Sans lettre", ""));
  for (const o of profil.offres) choix.append(new Option(`${o.a_lettre ? "✓ " : ""}${o.entreprise || "?"} — ${o.titre || ""}`.slice(0, 70), String(o.id)));
  const memo = (await api.storage.local.get("choix"))?.choix || {};
  const reconnue = profil.offres.find((o) => o.url === onglet.url) || profil.offres.find((o) => o.domaine && (hote === o.domaine || hote.endsWith("." + o.domaine)));
  choix.value = String((reconnue && reconnue.id) || memo[hote] || "");
  choix.onchange = async () => { memo[hote] = choix.value; await api.storage.local.set({ choix: memo }); etatLettre(); remplirCopier(); };
  etatLettre();
  remplirCopier();
}

function offreChoisie() { return profil.offres.find((o) => String(o.id) === $("#offre").value) || null; }

function etatLettre() {
  const o = offreChoisie(), z = $("#etat-lettre");
  z.textContent = "";
  if (!o) { z.append("Seulement tes informations et ton CV."); return; }
  if (o.a_lettre) { z.append("✓ Ta lettre est prête : elle ira dans le champ « lettre » s'il y en a un."); return; }
  z.append("Pas encore de lettre pour cette offre. ");
  const b = el("button", "lien", "Demander à mon agent"); b.type = "button";
  b.onclick = async () => {
    b.disabled = true;
    try { await appel(`/api/extension/lettre/${o.id}`, { methode: "POST" }); z.textContent = "C'est demandé : ton agent l'écrit (environ 1 minute). Clique ensuite sur « Actualiser »."; }
    catch (e) { z.textContent = e.message; }
  };
  z.append(b);
}

// La lettre sans l'en-tête (adresses, date, objet) : un champ « lettre de motivation » attend le texte
function corpsDeLettre(t) {
  const lignes = (t || "").split("\n");
  const i = lignes.findIndex((l) => /^\s*(madame|monsieur|dear|geachte|beste|bonjour|hello|to whom)/i.test(l));
  return (i >= 0 ? lignes.slice(i) : lignes).join("\n").trim();
}

function base64(tampon) {
  const octets = new Uint8Array(tampon); let s = "";
  for (let i = 0; i < octets.length; i += 0x8000) s += String.fromCharCode.apply(null, octets.subarray(i, i + 0x8000));
  return btoa(s);
}

// Exécuté DANS la page (chaque cadre) : reconstruit le CV et appelle le moteur de remplissage
function lancer(d) {
  if (typeof window.ApplaiRemplir !== "function") return null;
  let cv = null;
  if (d.cv) {
    const bin = atob(d.cv), octets = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) octets[i] = bin.charCodeAt(i);
    cv = new File([octets], d.cvNom, { type: "application/pdf" });
  }
  return window.ApplaiRemplir({ fiche: d.fiche, lettre: d.lettre, cv });
}

$("#remplir").onclick = async () => {
  const b = $("#remplir"), res = $("#resultat");
  b.disabled = true; res.className = "resultat"; res.textContent = "Je remplis…";
  try {
    const o = offreChoisie();
    const lettre = o && o.a_lettre ? corpsDeLettre((await appel(`/api/extension/lettre/${o.id}`)).lettre) : null;
    const cv = profil.cv ? base64(await appel("/api/extension/cv", { brut: true })) : null;
    const f = profil.fiche;
    const cvNom = `CV_${[f.prenom, f.nom].filter(Boolean).join("_").replace(/[^\w-]/g, "") || "candidat"}.pdf`;
    const cible = { tabId: onglet.id, allFrames: true };
    await api.scripting.executeScript({ target: cible, files: ["remplir.js"] });
    const resultats = await api.scripting.executeScript({ target: cible, func: lancer, args: [{ fiche: f, lettre, cv, cvNom }] });
    const r = resultats.map((x) => x.result).filter(Boolean);
    const champs = r.reduce((n, x) => n + x.remplis.filter((c) => c.champ !== "cv" && c.champ !== "lettre").length, 0);
    const joint = r.some((x) => x.cv), collee = r.some((x) => x.lettre);
    if (!champs && !joint && !collee) {
      res.textContent = "Aucun champ reconnu ici. Ouvre le formulaire (bouton « Postuler »), puis réessaie — ou copie les champs ci-dessous.";
    } else {
      res.className = "resultat ok";
      res.textContent = `✓ ${champs} champ(s) rempli(s)${joint ? " · CV joint" : (profil.cv ? " · CV à joindre toi-même" : "")}`
        + `${collee ? " · lettre collée" : ""}. Relis, puis clique « Envoyer » sur le site.`;
    }
  } catch (e) {
    res.textContent = e.message || "Impossible de remplir cette page.";
    if (e.connexion) montrer("connexion");
  }
  b.disabled = false;
};

// ---------- Secours : copier chaque champ ----------
function remplirCopier() {
  const z = $("#copier"); z.textContent = "";
  const ajouter = (lib, valeur, obtenir) => {
    const l = el("div", "ligne"); l.append(el("small", "", lib), el("span", "", valeur));
    const b = el("button", "", "Copier"); b.type = "button";
    b.onclick = async () => { try { await navigator.clipboard.writeText(obtenir ? await obtenir() : valeur); b.textContent = "Copié ✓"; setTimeout(() => (b.textContent = "Copier"), 1500); } catch (e) { b.textContent = "Échec"; } };
    l.append(b); z.append(l);
  };
  for (const [k, lib] of Object.entries(LIBELLES)) if (profil.fiche[k]) ajouter(lib, profil.fiche[k]);
  const o = offreChoisie();
  if (o && o.a_lettre) ajouter("Lettre", `${o.entreprise || ""}`, async () => corpsDeLettre((await appel(`/api/extension/lettre/${o.id}`)).lettre));
}

$("#actualiser").onclick = () => charger().catch((e) => { $("#resultat").textContent = e.message; if (e.connexion) montrer("connexion"); });
$("#deconnecter").onclick = async () => { await api.storage.local.remove("cle"); cle = null; $("#cle").value = ""; montrer("connexion"); };

(async () => {
  cle = (await api.storage.local.get("cle"))?.cle || null;
  if (!cle) return montrer("connexion");
  try { await charger(); } catch (e) { montrer(e.connexion ? "connexion" : "principal"); $("#erreur-cle").textContent = e.message; $("#resultat").textContent = e.message; }
})();
