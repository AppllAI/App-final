// Service de fond : la page (remplir.js) lui confie les questions libres du formulaire et le petit rapport de
// remplissage ; lui seul parle au serveur Applai, avec la clé de la personne. La fenêtre peut se fermer entre-temps.
"use strict";
const api = globalThis.browser ?? globalThis.chrome;
const API = "https://api.89-116-25-119.sslip.io";

async function envoyer(chemin, corps) {
  const { cle } = await api.storage.local.get("cle");
  if (!cle) return { erreur: "Extension non connectée." };
  try {
    const r = await fetch(API + chemin, { method: "POST", credentials: "omit",
      headers: { "X-Cle-Extension": cle, "Content-Type": "application/json" }, body: JSON.stringify(corps) });
    let d = {};
    try { d = await r.json(); } catch (e) { /* pas du JSON */ }
    return r.ok ? d : { erreur: d.detail || "Erreur " + r.status };
  } catch (e) { return { erreur: "Serveur Applai injoignable." }; }
}

api.runtime.onMessage.addListener((m, expediteur, repondre) => {
  if (!m || !expediteur.tab) return false;               // seulement depuis une page où elle a cliqué « Remplir »
  if (m.type === "questions") {
    envoyer("/api/extension/questions", { questions: m.questions, offre_id: m.offre_id || null }).then(repondre);
    return true;
  }
  if (m.type === "rapport") {
    envoyer("/api/extension/rapport", m.rapport).then(repondre);
    return true;
  }
  return false;
});
